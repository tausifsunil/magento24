var config = {
	paths: {
		'forever/elevatezoom'	: 'Forever_Productzoom/js/plugins/jquery.elevatezoom',
	},
	shim: {
		'forever/elevatezoom': {
			deps: ['jquery']
		}
	}
};
