<?php

/**
 * @Author: Alex Dong
 * @Date:   2020-07-09 16:45:27
 * @Last Modified by:   Alex Dong
 * @Last Modified time: 2020-07-09 16:46:08
 */

namespace Forever\Productzoom\Block;

class Zoom extends \Magento\Framework\View\Element\Template
{

}
