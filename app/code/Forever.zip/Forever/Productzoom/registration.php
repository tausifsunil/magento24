<?php

/**
 * @Author: nguyen
 * @Date:   2020-02-17 13:58:49
 * @Last Modified by:   Alex Dong
 * @Last Modified time: 2020-07-09 16:31:49
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Forever_Productzoom',
    __DIR__
);
