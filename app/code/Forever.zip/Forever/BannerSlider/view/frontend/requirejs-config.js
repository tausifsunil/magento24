var config = {
    map: {
        '*': {
            'carousel': 'Forever_BannerSlider/js/carousel',
            'owlCarousel': 'Forever_BannerSlider/js/owl-carousel/owl.carousel'
        }
    }
}