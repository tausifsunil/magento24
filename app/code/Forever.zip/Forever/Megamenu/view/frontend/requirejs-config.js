var config = {
    map: {
        '*': {
            'megamenu': "Forever_Megamenu/js/megamenu",
        },
    },
    shim: {
        'megamenu': {
            deps: ['jquery']
        },

    }

};
