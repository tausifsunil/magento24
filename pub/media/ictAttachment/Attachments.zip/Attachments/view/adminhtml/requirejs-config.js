var config = 
{
    map: 
    {
        '*': 
        {
            'Magento_Ui/js/form/element/file-uploader':'Ict_Attachments/js/form/element/file-uploader'
        }
    }
};